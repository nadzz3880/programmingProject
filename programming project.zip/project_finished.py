import csv
import tkinter as tk
from tkinter import filedialog, messagebox
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Global list to store CSV data
data = []

# File loading and data management
def load_data():
    """Load data from a CSV file."""
    global data
    file_path = input("Enter the path to the CSV file: ")
    try:
        with open(file_path, 'r') as file:
            reader = csv.DictReader(file)
            data = [{k.strip(): v.strip() for k, v in row.items()} for row in reader]
            print(f"\nData loaded successfully! Rows loaded: {len(data)}")
            print("\nPreview of the first 5 rows:")
            for row in data[:5]:
                print(row)
    except FileNotFoundError:
        print("Error: File not found.")
    except Exception as e:
        print(f"Error loading file: {e}")

def show_total_transactions():
    """Display total number of transactions."""
    if data:
        print(f"Total transactions: {len(data)}")
    else:
        print("No data loaded.")

def show_unique_locations_and_categories():
    """Show unique store locations and product categories."""
    if data:
        locations = {row['StoreLocation'] for row in data if 'StoreLocation' in row}
        categories = {row['ProductCategory'] for row in data if 'ProductCategory' in row}
        print(f"Unique Locations: {locations}")
        print(f"Unique Categories: {categories}")
    else:
        print("No data loaded.")

def show_transaction_details():
    """Display details for a specific transaction."""
    if data:
        transaction_id = input("Enter TransactionID: ")
        transaction = [row for row in data if row.get('TransactionID') == transaction_id]
        if transaction:
            print("Transaction Details:", transaction[0])
        else:
            print("Transaction not found.")
    else:
        print("No data loaded.")

def show_transactions_by_location():
    """Display transactions for a specific location."""
    if data:
        location = input("Enter store location: ")
        transactions = [row for row in data if row.get('StoreLocation') == location]
        if transactions:
            print(f"Transactions at {location}:")
            for transaction in transactions:
                print(transaction)
        else:
            print("No transactions for this location.")
    else:
        print("No data loaded.")

def show_transactions_by_category():
    """Display transactions for a specific product category."""
    if data:
        category = input("Enter product category: ")
        transactions = [row for row in data if row.get('ProductCategory') == category]
        if transactions:
            print(f"Transactions in {category}:")
            for transaction in transactions:
                print(transaction)
        else:
            print("No transactions for this category.")
    else:
        print("No data loaded.")

def summarize_sales():
    """Display a summary of sales data for a store location."""
    if not data:
        print("No data loaded.")
        return

    location = input("Enter store location: ")
    store_data = [row for row in data if row.get('StoreLocation') == location]

    if store_data:
        try:
            total_transactions = len({row['TransactionID'] for row in store_data})
            total_revenue = sum(float(row['TotalPrice']) for row in store_data if row.get('TotalPrice'))
            total_quantity = sum(int(row['Quantity']) for row in store_data if row.get('Quantity'))
            avg_satisfaction = sum(float(row['CustomerSatisfaction']) for row in store_data) / len(store_data)
            avg_transaction_value = total_revenue / total_transactions if total_transactions else 0

            print(f"\nSales Summary for {location}:")
            print(f"Total Transactions: {total_transactions}")
            print(f"Total Revenue: ${total_revenue:.2f}")
            print(f"Average Transaction Value: ${avg_transaction_value:.2f}")
            print(f"Total Quantity Sold: {total_quantity}")
            print(f"Average Satisfaction: {avg_satisfaction:.2f}\n")
        except Exception as e:
            print(f"Error summarizing sales: {e}")
    else:
        print("No data for this location.")

# Visualization using Tkinter and Matplotlib
def pie_chart():
    """Display a pie chart of revenue by location."""
    if not data:
        messagebox.showerror("Error", "No data loaded.")
        return

    revenue = {}
    for row in data:
        loc = row.get('StoreLocation')
        price = row.get('TotalPrice')
        if loc and price:
            try:
                revenue[loc] = revenue.get(loc, 0) + float(price)
            except ValueError:
                continue

    if revenue:
        fig = Figure()
        ax = fig.add_subplot(111)
        ax.pie(revenue.values(), labels=revenue.keys(), autopct='%1.1f%%')
        ax.set_title("Revenue by Location")
        plot_display(fig)
    else:
        messagebox.showwarning("Warning", "No valid data.")

def plot_histogram():
    """Display a histogram of transaction values."""
    if not data:
        messagebox.showerror("Error", "No data loaded.")
        return

    values = [float(row['TotalPrice']) for row in data if row.get('TotalPrice')]
    if values:
        fig = Figure()
        ax = fig.add_subplot(111)
        ax.hist(values, bins=10, color='blue', edgecolor='black')
        ax.set_title("Transaction Histogram")
        plot_display(fig)
    else:
        messagebox.showwarning("Warning", "No valid data.")

def plot_display(fig):
    """Display plots in Tkinter."""
    for widget in plot_frame.winfo_children():
        widget.destroy()
    canvas = FigureCanvasTkAgg(fig, master=plot_frame)
    canvas.draw()
    canvas.get_tk_widget().pack()

def launch_gui():
    """Launch the GUI."""
    global plot_frame
    root = tk.Tk()
    root.title("Data Analysis Tool")

    # Buttons
    button_frame = tk.Frame(root)
    button_frame.pack()
    tk.Button(button_frame, text="Pie Chart", command=pie_chart).pack()
    tk.Button(button_frame, text="Histogram", command=plot_histogram).pack()

    # Plot area
    plot_frame = tk.Frame(root)
    plot_frame.pack(fill=tk.BOTH, expand=True)

    root.mainloop()

# Main menu
def main_menu():
    """Display main menu for user choices."""
    while True:
        print("\nMenu:")
        print("1. Load Data")
        print("2. Total Transactions")
        print("3. Unique Locations & Categories")
        print("4. Transaction Details")
        print("5. Transactions by Location")
        print("6. Transactions by Category")
        print("7. Summarize Sales")
        print("8. Launch GUI")
        print("9. Exit")

        choice = input("Enter your choice: ")
        if choice == "1":
            load_data()
        elif choice == "2":
            show_total_transactions()
        elif choice == "3":
            show_unique_locations_and_categories()
        elif choice == "4":
            show_transaction_details()
        elif choice == "5":
            show_transactions_by_location()
        elif choice == "6":
            show_transactions_by_category()
        elif choice == "7":
            summarize_sales()
        elif choice == "8":
            launch_gui()
        elif choice == "9":
            print("Goodbye!")
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main_menu()

